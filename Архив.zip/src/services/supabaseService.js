import { createClient } from '@supabase/supabase-js';

// --- Ваши учетные данные Supabase ---
const supabaseUrl = 'https://orkpvyenyawrotzrfxeh.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9ya3B2eWVueWF3cm90enJmeGVoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA4NzA2NzgsImV4cCI6MjA2NjQ0NjY3OH0.ZNX-ftVym8B84qvzb85dYWa96XXFD_LEz73aXSbVEvQ';
// ------------------------------------

export const supabase = createClient(supabaseUrl, supabaseKey);

/**
 * Подписывается на изменения в таблице.
 * @param {string} channelName - Уникальное имя канала.
 * @param {object} options - Опции подписки (event, schema, table, filter).
 * @param {function} callback - Функция, вызываемая при получении события.
 * @returns {object} - Объект канала для последующей отписки.
 */
export const subscribe = (channelName, options, callback) => {
    const channel = supabase.channel(channelName);
    
    // --- ИЗМЕНЕНИЕ: Используем новый, правильный синтаксис для subscribe ---
    channel
        .on('postgres_changes', options, callback)
        .subscribe((status, err) => {
            if (status === 'SUBSCRIBED') {
                console.log(`Успешно подписаны на ${options.table} в канале ${channelName}`);
            }
            if (status === 'CHANNEL_ERROR') {
                console.error(`Ошибка канала подписки (${channelName}):`, err);
            }
            if (status === 'TIMED_OUT') {
                console.warn(`Тайм-аут подписки (${channelName}).`);
            }
        });

    // Возвращаем сам канал, чтобы его можно было удалить
    return channel;
};

/**
 * Отписывается от канала.
 * @param {object} channel - Объект канала, полученный от функции subscribe.
 */
export const removeSubscription = async (channel) => {
    // --- ИЗМЕНЕНИЕ: Теперь мы напрямую удаляем канал ---
    if (channel) {
        await supabase.removeChannel(channel);
    }
};

// ========================================================================
// Функции для работы с ОЧЕРЕДЯМИ (queues)
// ========================================================================

export const createQueue = (queueData) => {
    return supabase.rpc('create_queue_with_details', {
        p_queue_name: queueData.name,
        p_queue_description: queueData.description,
        p_window_count: queueData.window_count,
        p_services_payload: queueData.services_payload
    }).single();
};

export const deleteQueue = (queueId) => supabase.from('queues').delete().eq('id', queueId);
export const getQueueById = (queueId) => supabase.from('queues').select('*').eq('id', queueId).single();
export const getQueueByShortId = (shortId) => supabase.from('queues').select('*').eq('short_id', shortId).single();
export const getQueueBySecret = (secretKey) => supabase.from('queues').select('*').eq('admin_secret_key', secretKey).single();
export const updateQueueStatus = (queueId, status) => supabase.from('queues').update({ status }).eq('id', queueId);

export const getQueueDetailsForJoining = async (queueId) => {
    const { data: queue, error: queueError } = await getQueueById(queueId);
    if (queueError) return { queue: null, services: [], error: queueError };
    const { data: services, error: servicesError } = await supabase.from('services').select('*').eq('queue_id', queueId);
    return { queue, services, error: servicesError };
};

// ========================================================================
// Функции для работы с УЧАСТНИКАМИ (queue_members)
// ========================================================================

export const createMember = (memberData) => supabase.from('queue_members').insert([memberData]).select().single();
export const deleteMember = (memberId) => supabase.from('queue_members').delete().eq('id', memberId);
export const getMemberById = (memberId) => supabase.from('queue_members').select('*, queues(*), services(*), windows(*)').eq('id', memberId).single();
export const updateMemberStatus = (memberId, status) => supabase.from('queue_members').update({ status }).eq('id', memberId);
export const getMembersByQueueId = (queueId) => supabase.from('queue_members').select('*, service_name:services(name), window_name:windows(name)').eq('queue_id', queueId).order('ticket_number');
export const getWaitingMembersCount = (queueId, ticketNumber) => supabase.from('queue_members').select('*', { count: 'exact', head: true }).eq('queue_id', queueId).eq('status', 'waiting').lt('ticket_number', ticketNumber);
export const returnMemberToWaiting = (memberId) => supabase.from('queue_members').update({ status: 'waiting', assigned_window_id: null }).eq('id', memberId);

// ========================================================================
// Функции для работы с УСЛУГАМИ (services, window_services)
// ========================================================================

export const addService = (queueId, serviceName) => supabase.from('services').insert({ queue_id: queueId, name: serviceName });
export const removeService = (serviceId) => supabase.from('services').delete().eq('id', serviceId);
export const updateServiceName = (serviceId, newName) => supabase.from('services').update({ name: newName }).eq('id', serviceId);
export const getServicesByQueueId = (queueId) => supabase.from('services').select('*').eq('queue_id', queueId);
export const setServicesForWindow = (windowId, serviceIds) => supabase.rpc('set_services_for_window', { p_window_id: windowId, p_service_ids: serviceIds });

// ========================================================================
// Функции для работы с ОКНАМИ (windows)
// ========================================================================

export const getWindowsByQueueId = (queueId) => supabase.from('windows').select('*, window_services(service_id)').eq('queue_id', queueId).order('name');
export const getWindowBySecretKey = (secretKey) => supabase.from('windows').select('*, queues(*)').eq('admin_secret_key', secretKey).single();


// ========================================================================
// RPC Функции (вызов функций из БД)
// ========================================================================

export const getMembersForWindow = (windowId) => {
    return supabase.rpc('get_members_for_window', {
      window_id_param: windowId
    });
};

export const callNextMemberToWindow = (windowId) => {
    return supabase.rpc('call_next_member_to_window', {
        p_window_id: windowId
    });
};

export const callSpecificMember = (memberId, windowId) => {
    return supabase.from('queue_members').update({
        status: 'called',
        assigned_window_id: windowId
    }).eq('id', memberId);
};