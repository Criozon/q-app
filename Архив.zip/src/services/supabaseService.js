import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Supabase URL and Anon Key are required. Please check your .env file.");
}

const supabase = createClient(supabaseUrl, supabaseAnonKey);

// ==========================================================================
// RPC ФУНКЦИИ (безопасные точки входа)
// ==========================================================================

export async function getQueueDetailsForJoining(queueId) {
  return await supabase.rpc('get_queue_details_for_join_page', { p_queue_id: queueId });
}

export async function createQueue(queueData) {
  return await supabase.rpc('create_queue_with_dependencies', {
    p_name: queueData.name,
    p_description: queueData.description,
    p_window_count: queueData.window_count,
    p_services: queueData.services_payload
  });
}

export async function getQueueBySecret(secretKey) {
  return await supabase
    .rpc('get_queue_by_admin_secret', { p_admin_secret_key: secretKey })
    .single();
}

export async function callNextMemberToWindow(windowId) {
    return await supabase.rpc('call_next_member', { p_window_id: windowId });
}

export async function setServicesForWindow(windowId, serviceIds) {
    return await supabase.rpc('set_services_for_window', {
        p_window_id: windowId,
        p_service_ids: serviceIds
    });
}

export async function getWindowBySecretKey(windowSecretKey) {
    return await supabase
      .from('windows')
      .select('id, name, queue_id, queues (id, name, status)')
      .eq('admin_secret_key', windowSecretKey)
      .single();
}


// ==========================================================================
// Функции для работы с ОЧЕРЕДЯМИ (Queues)
// ==========================================================================

export async function getQueueById(queueId) {
  return await supabase
    .from('queues')
    .select('id, name, description, status, created_at, window_count')
    .eq('id', queueId)
    .single();
}

export async function updateQueueStatus(queueId, newStatus) {
  return await supabase
    .from('queues')
    .update({ status: newStatus })
    .eq('id', queueId);
}

export async function deleteQueue(queueId) {
  return await supabase
    .from('queues')
    .delete()
    .eq('id', queueId);
}


// ==========================================================================
// Функции для работы с УЧАСТНИКАМИ (Members)
// ==========================================================================

export async function createMember(memberData) {
    return await supabase
      .from('queue_members')
      .insert([memberData])
      .select()
      .single();
}

// Эта функция остается для Мастер-Администратора - он видит всех.
export async function getMembersByQueueId(queueId) {
  return await supabase
    .from('queue_members')
    .select(`*, services (name), windows (name)`)
    .eq('queue_id', queueId)
    .order('ticket_number', { ascending: true });
}


// --- НАЧАЛО ИЗМЕНЕНИЯ: Новая функция для оператора окна ---
/**
 * Получает отфильтрованный список участников, подходящих для конкретного окна.
 * @param {string} windowId - ID окна, для которого получаем список.
 * @param {string} queueId - ID очереди.
 * @returns {Promise<Array>} - Массив подходящих участников.
 */
export async function getMembersForWindow(windowId, queueId) {
  // Получаем список ID услуг, которые оказывает это окно
  const { data: windowServices } = await supabase
    .from('window_services')
    .select('service_id')
    .eq('window_id', windowId);

  const serviceIds = windowServices.map(s => s.service_id);

  let query = supabase
    .from('queue_members')
    .select('*, services (name), windows (name)')
    .eq('queue_id', queueId)
    // Показываем только тех, кто ждет, или уже вызван (возможно, другим окном)
    .in('status', ['waiting', 'called', 'acknowledged']);

  // Если у окна есть конкретные услуги, фильтруем по ним + "общие" клиенты
  if (serviceIds.length > 0) {
    query = query.or(`service_id.is.null,service_id.in.(${serviceIds.join(',')})`);
  }
  // Если у окна нет услуг, оно "общее" и может видеть всех ожидающих.

  return await query.order('ticket_number', { ascending: true });
}
// --- КОНЕЦ ИЗМЕНЕНИЯ ---


export async function getMemberById(memberId) {
    return await supabase
      .from('queue_members')
      .select('*, queues (id, name), windows (name)')
      .eq('id', memberId)
      .single();
}

export async function deleteMember(memberId) {
  return await supabase
    .from('queue_members')
    .delete()
    .eq('id', memberId);
}

export async function updateMemberStatus(memberId, newStatus) {
    return await supabase
        .from('queue_members')
        .update({ status: newStatus })
        .eq('id', memberId);
}

export async function returnMemberToWaiting(memberId) {
    return await supabase
        .from('queue_members')
        .update({ status: 'waiting', assigned_window_id: null })
        .eq('id', memberId);
}

export async function assignAndCallMember(memberId, windowId) {
    return await supabase
        .from('queue_members')
        .update({ status: 'called', assigned_window_id: windowId })
        .eq('id', memberId);
}

export async function getWaitingMembersCount(queueId, ticketNumber) {
    return await supabase
      .from('queue_members')
      .select('*', { count: 'exact', head: true })
      .eq('queue_id', queueId)
      .eq('status', 'waiting')
      .lt('ticket_number', ticketNumber);
}


// ==========================================================================
// Функции для работы с ОКНАМИ (Windows)
// ==========================================================================

export async function getWindowsByQueueId(queueId) {
  return await supabase
    .from('windows')
    .select('id, name, queue_id, admin_secret_key, window_services(service_id)')
    .eq('queue_id', queueId)
    .order('name', { ascending: true });
}


// ==========================================================================
// Функции для работы с УСЛУГАМИ (Services)
// ==========================================================================

export async function getServicesByQueueId(queueId) {
  return await supabase
    .from('services')
    .select('*')
    .eq('queue_id', queueId)
    .order('created_at', { ascending: true });
}

export async function addService(queueId, serviceName) {
    return await supabase
        .from('services')
        .insert([{ queue_id: queueId, name: serviceName }]);
}

export async function removeService(serviceId) {
    return await supabase
        .from('services')
        .delete()
        .eq('id', serviceId);
}

// ==========================================================================
// Функции для Realtime-подписок
// ==========================================================================

export function subscribe(channelName, options, callback) {
  const channel = supabase
    .channel(channelName)
    .on(`postgres_changes`, options, callback)
    .subscribe((status, err) => {
        if (err) {
            console.log(`Error subscribing to ${channelName}:`, err);
        }
    });
  return channel;
}

export function removeSubscription(channel) {
  if (channel) {
    supabase.removeChannel(channel);
  }
}