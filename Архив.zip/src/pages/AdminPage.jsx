import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../supabaseClient';
import toast from 'react-hot-toast';
import QRCode from 'qrcode';
import { QrCode, Check, PhoneCall, UserX, ChevronRight } from 'lucide-react';

import Card from '../components/Card';
import Modal from '../components/Modal';
import Button from '../components/Button';
import styles from './AdminPage.module.css';
import log from '../utils/logger';

const PAGE_SOURCE = 'AdminPage';

function AdminPage() {
    const { secretKey } = useParams();
    const [queue, setQueue] = useState(null);
    const [members, setMembers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [qrCodeUrl, setQrCodeUrl] = useState('');
    const [joinUrl, setJoinUrl] = useState('');
    const [isButtonLoading, setIsButtonLoading] = useState(false);

    const listRef = useRef(null);

    const calledMember = members.find(m => m.status === 'called');
    const waitingMembersCount = members.filter(m => m.status === 'waiting').length;

    const fetchAllData = useCallback(async (showLoader = false) => {
        if (showLoader) setLoading(true);
        setError(null);
        log(PAGE_SOURCE, 'Загрузка всех данных...');
        try {
            const { data: qData, error: qError } = await supabase
                .from('queues').select('*').eq('admin_secret_key', secretKey).single();
            if (qError || !qData) throw new Error("Очередь не найдена или была удалена.");
            setQueue(qData);

            const { data: mData, error: mError } = await supabase
                .from('queue_members').select('*').eq('queue_id', qData.id).order('ticket_number');
            if (mError) throw new Error("Не удалось загрузить участников.");
            setMembers(mData || []);

            if (showLoader) {
                const currentJoinUrl = `${window.location.origin}/join/${qData.id}`;
                setJoinUrl(currentJoinUrl);
                const qrUrl = await QRCode.toDataURL(currentJoinUrl);
                setQrCodeUrl(qrUrl);
                if (mData.length === 0) setIsModalOpen(true);
            }
        } catch (err) {
            log(PAGE_SOURCE, 'Ошибка при загрузке:', err.message);
            setError(err.message);
            setQueue(null);
        } finally {
            if (showLoader) setLoading(false);
        }
    }, [secretKey]);

    useEffect(() => {
        if (!queue) {
            return;
        }
        const handleRealtimeEvent = (payload) => {
            log(PAGE_SOURCE, `Realtime событие ${payload.eventType} получено`);
            if (payload.eventType === 'INSERT') {
                setMembers(currentMembers => [...currentMembers, payload.new].sort((a,b) => a.ticket_number - b.ticket_number));
            }
            if (payload.eventType === 'UPDATE') {
                setMembers(currentMembers => currentMembers.map(m => m.id === payload.new.id ? payload.new : m));
            }
            if (payload.eventType === 'DELETE') {
                setMembers(currentMembers => currentMembers.filter(m => m.id !== payload.old.id));
            }
        };

        const channel = supabase.channel(`admin-page-${queue.id}`)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'queue_members', filter: `queue_id=eq.${queue.id}` }, handleRealtimeEvent)
            .subscribe(status => log(PAGE_SOURCE, `Статус подписки: ${status}`));
        
        return () => {
            log(PAGE_SOURCE, 'Очистка подписки на Realtime');
            supabase.removeChannel(channel);
        };
    }, [queue]);

    useEffect(() => {
        const handlePageShow = (event) => {
            if (event.persisted) {
                log(PAGE_SOURCE, 'Страница восстановлена из bfcache, принудительно обновляем.');
                fetchAllData(true);
            }
        };
        
        window.addEventListener('pageshow', handlePageShow);
        fetchAllData(true);
        
        return () => window.removeEventListener('pageshow', handlePageShow);
    }, [fetchAllData]);

    const autoScroll = useCallback(() => { /* ... */ }, [members]);
    useEffect(() => { autoScroll(); }, [members, autoScroll]);

    const handleMainButtonClick = async () => {
        setIsButtonLoading(true);
        const memberToUpdate = calledMember || members.find(m => m.status === 'waiting');
        if (memberToUpdate) {
            const newStatus = calledMember ? 'serviced' : 'called';
            await supabase.from('queue_members').update({ status: newStatus }).eq('id', memberToUpdate.id);
        }
        setIsButtonLoading(false);
    };
    
    const handleCallSpecific = async (memberId) => {
        if (calledMember) { toast.error('Завершите текущее обслуживание.'); return; }
        await supabase.from('queue_members').update({ status: 'called' }).eq('id', memberId);
    };
    
    const handleRemoveMember = async (memberId) => {
        if (window.confirm('Удалить участника?')) {
            await supabase.from('queue_members').delete().eq('id', memberId);
        }
    };
    
    const handleShare = () => { /* ... */ };

    if (loading) return <div className="container" style={{ textAlign: 'center', paddingTop: '40px' }}>Загрузка...</div>;
    if (error) return <div className="container" style={{ textAlign: 'center', paddingTop: '40px' }}>{error}</div>;

    return (
        <div className={styles.pageWrapper}>
            <header className={styles.header}>
                <div className={`container ${styles.headerContent}`}>
                    <div className={styles.placeholder}></div>
                    <div className={styles.headerCenter}>
                        <h1 className={styles.headerTitle}>{queue?.name}</h1>
                        <p className={styles.queueCount}>В очереди: {waitingMembersCount}</p>
                    </div>
                    <button onClick={() => setIsModalOpen(true)} className={styles.qrButton}><QrCode size={24} color="var(--accent-blue)" /></button>
                </div>
            </header>
            <main ref={listRef} className={`container ${styles.mainContent}`}>
                <div className={styles.memberList}>
                    {members.map(member => {
                        const memberCardClasses = [ styles.memberCard, member.status === 'called' && styles.called, member.status === 'serviced' && styles.serviced ].filter(Boolean).join(' ');
                        return (
                            <div id={`member-${member.id}`} key={member.id}>
                                <Card className={memberCardClasses}>
                                    <div className={styles.memberInfo}>
                                        <p className={styles.memberName}>{member.display_code || `#${member.ticket_number}`} - {member.member_name}</p>
                                        <p className={styles.memberStatus}>{member.status === 'called' ? 'Вызывается...' : (member.status === 'serviced' ? 'Обслужен' : 'Ожидает')}</p>
                                    </div>
                                    <div className={styles.memberActions}>
                                        {member.status === 'waiting' && <Button onClick={() => handleCallSpecific(member.id)} disabled={!!calledMember || isButtonLoading} className={`${styles.actionButton} ${styles.priorityCallButton}`} title="Приоритетный вызов"><ChevronRight size={20} /></Button>}
                                        <Button onClick={() => handleRemoveMember(member.id)} disabled={isButtonLoading} className={`${styles.actionButton} ${styles.removeButton}`} title="Удалить"><UserX size={20} /></Button>
                                    </div>
                                </Card>
                            </div>
                        )
                    })}
                    {members.length === 0 && <p className={styles.emptyQueueText}>В очереди пока никого нет.</p>}
                </div>
            </main>
            <footer className={styles.footer}>
                <div className="container">
                    <Button onClick={handleMainButtonClick} disabled={(!calledMember && waitingMembersCount === 0) || isButtonLoading} style={{ backgroundColor: calledMember ? 'var(--accent-green)' : 'var(--accent-blue)' }}>
                        {isButtonLoading ? '...' : (calledMember ? <><Check size={20} /> Завершить ({calledMember.display_code || calledMember.ticket_number})</> : <><PhoneCall size={20} /> Вызвать следующего</>)}
                    </Button>
                </div>
            </footer>
            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Покажите QR-код или отправьте ссылку">
                <div className={styles.modalContent}>
                    {qrCodeUrl && <img src={qrCodeUrl} alt="QR Code" className={styles.qrImage} />}
                    <p className={styles.joinLink}>{joinUrl}</p>
                    <Button onClick={handleShare}>Поделиться</Button>
                </div>
            </Modal>
        </div>
    );
}

export default AdminPage;