import { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import QRCode from 'qrcode';
import log from '../utils/logger';
import * as service from '../services/supabaseService';

const PAGE_SOURCE = 'WindowAdminContext';
const WindowAdminContext = createContext(null);

export function WindowAdminProvider({ children }) {
    const { windowSecretKey } = useParams();
    const [windowInfo, setWindowInfo] = useState(null);
    const [queueInfo, setQueueInfo] = useState(null);
    const [members, setMembers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
    const [joinUrl, setJoinUrl] = useState('');
    const [qrCodeUrl, setQrCodeUrl] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);

    const loadInitialData = useCallback(async (isInitialLoad = false) => {
        if (isInitialLoad) {
            setLoading(true);
            setError(null);
        }
        try {
            const { data: wData, error: wError } = await service.getWindowBySecretKey(windowSecretKey);
            
            if (wError || !wData) {
                throw new Error("Панель управления не найдена. Неверный ключ доступа.");
            }

            if (wData && !wData.queues) {
                log(PAGE_SOURCE, "Окно найдено, но очередь удалена. Показываем пустой список.");
                setWindowInfo({ id: wData.id, name: wData.name, queue_id: wData.queue_id });
                setQueueInfo(null);
                setMembers([]);
                setError(null);
                if (isInitialLoad) setLoading(false);
                return;
            }

            const currentWindowInfo = { id: wData.id, name: wData.name, queue_id: wData.queue_id };
            setWindowInfo(currentWindowInfo);
            setQueueInfo(wData.queues);
            
            // --- ГЛАВНОЕ ИЗМЕНЕНИЕ: Вызываем нашу новую RPC функцию ---
            const { data: mData, error: mError } = await service.getMembersForWindow(currentWindowInfo.id);

            if (mError) throw new Error("Не удалось загрузить список участников.");
            setMembers(mData || []);
            
            if (!joinUrl && wData.queues) {
                const clientJoinUrl = `${window.location.origin}/#/join/${wData.queues.short_id}`;
                setJoinUrl(clientJoinUrl);
                const qrUrl = await QRCode.toDataURL(clientJoinUrl);
                setQrCodeUrl(qrUrl);
            }
        } catch (err) {
            log(PAGE_SOURCE, 'Ошибка при загрузке:', err);
            if (isInitialLoad) setError(err.message || 'Произошла неизвестная ошибка');
        } finally {
            if (isInitialLoad) setLoading(false);
        }
    }, [windowSecretKey, joinUrl]);
    
    useEffect(() => { loadInitialData(true); }, [loadInitialData]);
    
    useEffect(() => {
        if (!queueInfo || !windowInfo) return;

        const handleRealtimeUpdate = (payload) => {
            log(PAGE_SOURCE, `Получено Realtime событие (${payload.table}), перезагружаем данные.`);
            loadInitialData(false);
        };

        const memberChannel = service.subscribe(`window-admin-members-${queueInfo.id}`, { event: '*', schema: 'public', table: 'queue_members', filter: `queue_id=eq.${queueInfo.id}` }, handleRealtimeUpdate);
        const queueChannel = service.subscribe(`window-admin-queue-${queueInfo.id}`, { event: '*', schema: 'public', table: 'queues', filter: `id=eq.${queueInfo.id}`}, handleRealtimeUpdate);
        const servicesChannel = service.subscribe(`window-admin-services-${queueInfo.id}`, { event: '*', schema: 'public', table: 'window_services' }, handleRealtimeUpdate);

        return () => {
            service.removeSubscription(memberChannel);
            service.removeSubscription(queueChannel);
            service.removeSubscription(servicesChannel);
        };
    }, [queueInfo, windowInfo, loadInitialData]);

    const callNext = useCallback(async () => {
        if (!windowInfo || !queueInfo) return;
        setIsProcessing(true);
        try {
            await service.callNextMemberToWindow(windowInfo.id);
            // Данные обновятся по real-time, но можно и принудительно
            // await loadInitialData(false); 
        } catch (error) {
            toast.error("Не удалось вызвать участника.");
        } finally {
            setIsProcessing(false);
        }
    }, [windowInfo, queueInfo]);

    const callSpecific = useCallback(async (memberId, assignedMember) => {
        if (assignedMember) {
             toast.error('Завершите текущее обслуживание, чтобы вызвать другого участника.');
             return;
        }
        setIsProcessing(true);
        try {
            await service.callSpecificMember(memberId, windowInfo.id);
        } catch(error) {
            toast.error("Не удалось вызвать этого участника.");
        } finally {
            setIsProcessing(false);
        }
    }, [windowInfo]);

    const completeService = useCallback(async (memberId) => {
        setIsProcessing(true);
        try {
            await service.updateMemberStatus(memberId, 'serviced');
        } finally {
            setIsProcessing(false);
        }
    }, []);

    const returnToQueue = useCallback(async (memberId) => {
        setIsProcessing(true);
        try {
            await service.returnMemberToWaiting(memberId);
        } finally {
            setIsProcessing(false);
        }
    }, []);
    
    const assignedMember = useMemo(() => members.find(m => m.assigned_window_id === windowInfo?.id && (m.status === 'called' || m.status === 'acknowledged')), [members, windowInfo]);
    
    const value = useMemo(() => ({ 
        windowInfo, queueInfo, members, assignedMember, loading, error, isProcessing, isJoinModalOpen, joinUrl, qrCodeUrl, setIsJoinModalOpen, loadInitialData, callNext, callSpecific, completeService, returnToQueue 
    }), [windowInfo, queueInfo, members, assignedMember, loading, error, isProcessing, isJoinModalOpen, joinUrl, qrCodeUrl, setIsJoinModalOpen, loadInitialData, callNext, callSpecific, completeService, returnToQueue]);
    
    return (<WindowAdminContext.Provider value={value}>{children}</WindowAdminContext.Provider>);
}

export function useWindowAdmin() {
    const context = useContext(WindowAdminContext);
    if (context === null) throw new Error('useWindowAdmin должен использоваться внутри WindowAdminProvider');
    return context;
}